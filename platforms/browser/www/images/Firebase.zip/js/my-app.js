  
// If we need to use custom DOM library, let's save it to $$ variable:
var $$ = Dom7;


var mostrarErrores = 1;


var app = new Framework7({
    // App root element
    root: '#app',
    // App Name
    name: 'My App',
    // App id
    id: 'com.myapp.test',
    // Enable swipe panel
    panel: {
      swipe: 'left',
    },
    // Add default routes
    routes: [
      {
        path: '/',
        url: 'index.html',
      },
      {
        path: '/index/',
        url: 'index.html',
      },
      {
        path: '/panel/',
        url: 'panel.html',
      },
      {
        path: '/panel_admin/',
        url: 'panel_admin.html',
      },
      {
        path: '/juego/',
        url: 'juego.html',
      },
      {
        path: '/datospersonales/',
        url: 'datospersonales.html',
      },
    ]
    // ... other parameters
  });

var mainView = app.views.create('.view-main');

var toques = 0;

var nombre, apellido , paginaweb , telefono , fnac , email;



/* BASE DE DATOS */
var db, refUsuarios, refTiposUsuarios;



// Handle Cordova Device Ready Event
$$(document).on('deviceready', function() {

  /* seteo variables de BD */

  db = firebase.firestore();
  refUsuarios = db.collection("USUARIOS");
  refTiposUsuarios= db.collection("TIPOS_USUARIOS");

  var iniciarDatos = 0;
  if ( iniciarDatos == 1 ) {
      fnIniciarDatos();
  }



    fnMostrarError("Device is ready!");
    

    $$('#registro').on('click', fnRegistro);
    $$('#login').on('click', fnLogin);

    $$('#prueba').on('click', fnPruebaUsuario);



});

// Option 1. Using one 'page:init' handler for all pages
$$(document).on('page:init', function (e) {
    // Do something here when page loaded and initialized
    fnMostrarError(e);
})




// Option 2. Using live 'page:init' event handlers for each page
$$(document).on('page:init', '.page[data-name="index"]', function (e) {
    // Inicio Panel
    fnMostrarError(e);
    
    //$$('#inicio').on('click', fnSetEmail);


})
$$(document).on('page:init', '.page[data-name="panel"]', function (e) {
    // Inicio Panel
    fnMostrarError(e);
    
    $$('#setNombre').on('click', fnSetNombre);



})


$$(document).on('page:init', '.page[data-name="datospersonales"]', function (e) {
    // Inicio datospersonales
    $$('#guardar').on('click', fnGuardarDP);


})



$$(document).on('page:init', '.page[data-name="juego"]', function (e) {
    // Inicio Juego
    fnMostrarError(e);

    var columnas = 5;
    var filas = 5;
    var datos = "";



    for (j=0; j<filas; j++) {
        datos = '<div class="row">';
        for (i=0; i<columnas; i++) {
          datos += '<div class="col tocoCol" id="col_'+j+'_'+i+'">'+i+'</div>';
        }
        datos += '</div>';
        $$('#grilla').append(datos);
    }


    $$('.tocoCol').on('click', fnTocaCol);


})


/* MIS FUNCIONES */
function fnRegistro() {

    var elMail = $$('#email').val(); // es un input... uso val!
    var laClave = $$('#clave').val(); // es un input... uso val!

    email = elMail;

    var huboError = 0;

    firebase.auth().createUserWithEmailAndPassword(elMail, laClave)          
      .catch(function(error) {       
        // Handle Errors here.
        huboError = 1;
        var errorCode = error.code;
        var errorMessage = error.message; 
        
        fnMostrarError(errorCode);
        fnMostrarError(errorMessage);
      })
      .then(function(){
          if(huboError == 0){
            // alert('OK');
            // lo seteo en el panel.... contenedor lblEmail
            $$('#lblEmail').text(elMail);   // es una etiqueta html. Text va sin formato
            mainView.router.navigate("/datospersonales/");
          }
      });
}

function fnLogin() {


    email = $$('#email').val();
    var clave = $$('#clave').val();
       
//Se declara la variable huboError (bandera)
    var huboError = 0;
        
    firebase.auth().signInWithEmailAndPassword(email, clave)
        .catch(function(error){
//Si hubo algun error, ponemos un valor referenciable en la variable huboError
            huboError = 1;
            var errorCode = error.code;
            var errorMessage = error.message;
            fnMostrarError(errorMessage);
            fnMostrarError(errorCode);
        })
        .then(function(){   
//En caso de que esté correcto el inicio de sesión y no haya errores, se dirige a la siguiente página
            if(huboError == 0){

                tipoUsuario = "";

                // recuperar el tipo de usuario segun el email logueado....
                // REF: https://firebase.google.com/docs/firestore/query-data/get-data
                // TITULO: Obtén un documento
                
                refUsuarios.doc(email).get().then(function(doc) {
                      if (doc.exists) {
                          //console.log("Document data:", doc.data());
                          //console.log("Tipo de Usuario: " + doc.data().tipo );
                          tipoUsuario = doc.data().tipo;

                          if ( tipoUsuario == "VIS" ) {
                              mainView.router.navigate("/panel/");
                          }
                          if ( tipoUsuario == "ADM" ) {
                              mainView.router.navigate("/panel_admin/");
                          }
                          


                      } else {
                          // doc.data() will be undefined in this case
                          //console.log("No such document!");
                      }
                }).catch(function(error) {
                    console.log("Error getting document:", error);
                });


            }

        }); 




}



function fnSetNombre() {
    var elNombre = $$('#nombre').val(); // es un input... uso val!
    // lo seteo en el panel.... contenedor lblNombre
    $$('#lblNombre').text(elNombre);   // es una etiqueta html. Text va sin formato
}

function fnTocaCol() {

    elId = this.id;
    fnMostrarError(elId);

    if ( toques % 2 == 0 ) {
      $$('#'+elId).addClass('color1');
      $$('#c1').removeClass('btnSeleccionado');
      $$('#c2').addClass('btnSeleccionado');
    } else {
      $$('#'+elId).addClass('color2');
      $$('#c2').removeClass('btnSeleccionado');
      $$('#c1').addClass('btnSeleccionado');
    }

    toques++;
}



function fnPruebaUsuario() {

    fnMostrarError('Entro en fnPruebaUsuario');

    // pruebo registro de usuario en firebase.
    var email="otro@lkjhslkjahlkahsd.com";
    var password="wertyuijnas";

    firebase.auth().createUserWithEmailAndPassword(email, password)             
      .catch(function(error) {          
        // Handle Errors here.
        var errorCode = error.code;
        var errorMessage = error.message; 
        
        fnMostrarError(errorCode);
        fnMostrarError(errorMessage);
      });
}


function fnGuardarDP() {
  nombre = $$('#nombre').val();
  apellido = $$('#apellido').val();
  paginaweb = $$('#paginaweb').val();
  telefono = $$('#telefono').val();
  fnac = $$('#fnac').val();

  // clave: variable de datos

  var data = {
    nombre: nombre,
    apellido: apellido,
    web: paginaweb,
    telefono: telefono,
    fnac: fnac,
    tipo: "VIS"
  }



  refUsuarios.doc(email).set(data);



}







function fnIniciarDatos() {

    codido = "VIS"; tipo = "Visitantes"; saludo = "Hola Visitante";
    var data = {
      tipo: tipo, saludo: saludo
    }
    refTiposUsuarios.doc(codido).set(data);

    codido = "ADM"; tipo = "Administrador"; saludo = "Hola Mr. Admin";
    var data = {
      tipo: tipo, saludo: saludo
    }
    refTiposUsuarios.doc(codido).set(data);

    codido = "COM"; tipo = "Comercio"; saludo = "Hola Comercio";
    var data = {
      tipo: tipo, saludo: saludo
    }
    refTiposUsuarios.doc(codido).set(data);

    var data = {
      nombre: "Admin",
      apellido: "Apellido",
      web: "web.com",
      telefono: "1234",
      fnac: "01/01/1999",
      tipo: "ADM"
    }
    refUsuarios.doc("admin@admin.com").set(data);


}



function fnMostrarError(txt) {
  if (mostrarErrores == 1) {
      console.log("ERROR: " + txt);
  }
}



